﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWiseWorks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWiseWorks))
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.PanelDDMen = New System.Windows.Forms.Panel()
        Me.BtnClothing = New System.Windows.Forms.Button()
        Me.BtnShoes = New System.Windows.Forms.Button()
        Me.BtnMen = New System.Windows.Forms.Button()
        Me.PanelDDWomen = New System.Windows.Forms.Panel()
        Me.BtnWomenClothes = New System.Windows.Forms.Button()
        Me.BtnWomenShoes = New System.Windows.Forms.Button()
        Me.BtnWomen = New System.Windows.Forms.Button()
        Me.btnAccessories = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.PicBoxNike1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxJordan2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxJordan1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxAdidas1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxAdidas2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNike2 = New System.Windows.Forms.PictureBox()
        Me.btnMenNike1 = New System.Windows.Forms.Button()
        Me.btnMenAdidas1 = New System.Windows.Forms.Button()
        Me.btnMenJordan1 = New System.Windows.Forms.Button()
        Me.lblMenNike = New System.Windows.Forms.Label()
        Me.lblMenAdidas = New System.Windows.Forms.Label()
        Me.lblMenJordan = New System.Windows.Forms.Label()
        Me.PicBoxCart = New System.Windows.Forms.PictureBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btnCheckout = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.lblTotalAmount = New System.Windows.Forms.Label()
        Me.PicBoxNikeCloth1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNikeCloth2 = New System.Windows.Forms.PictureBox()
        Me.lblMenNikeCloth = New System.Windows.Forms.Label()
        Me.PicBoxAdidasCloth1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxAdidasCloth2 = New System.Windows.Forms.PictureBox()
        Me.lblMenAdidasCloth = New System.Windows.Forms.Label()
        Me.PicBoxJordanCloth = New System.Windows.Forms.PictureBox()
        Me.PicBoxJordanCloth2 = New System.Windows.Forms.PictureBox()
        Me.lblMenJordanCloth = New System.Windows.Forms.Label()
        Me.btnJordanCloth = New System.Windows.Forms.Button()
        Me.btnAdidasCloth = New System.Windows.Forms.Button()
        Me.btnNikeCloth = New System.Windows.Forms.Button()
        Me.PicBoxAdidasWomenCloth1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxAdidasWomenCloth2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenPumaCloth1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenPumaCloth2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenNikeCloth1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenNikeCloth2 = New System.Windows.Forms.PictureBox()
        Me.btnWomenPuma = New System.Windows.Forms.Button()
        Me.btnWomenAdidas = New System.Windows.Forms.Button()
        Me.btnWomenNike = New System.Windows.Forms.Button()
        Me.lblWomenNikeCloth = New System.Windows.Forms.Label()
        Me.lblWomenAdidasCloth = New System.Windows.Forms.Label()
        Me.lblWomenPumaCloth = New System.Windows.Forms.Label()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.PicBoxWomenAdidasShoes1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenAdidasShoes2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenNikeShoes1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenNikeShoes2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxWomenJordanShoes1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxFannyPack2 = New System.Windows.Forms.PictureBox()
        Me.btnWomenJordanShoes = New System.Windows.Forms.Button()
        Me.btnWomenShoesAdidas = New System.Windows.Forms.Button()
        Me.btnWomenShoesNike = New System.Windows.Forms.Button()
        Me.lblWomenAdidasShoes = New System.Windows.Forms.Label()
        Me.lblWomenNikeShoes = New System.Windows.Forms.Label()
        Me.lblWomenJordanShoes = New System.Windows.Forms.Label()
        Me.PicBoxFannyPack1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNikeSocks1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNikeSocks2 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNikeBackPack1 = New System.Windows.Forms.PictureBox()
        Me.PicBoxNikeBackPack2 = New System.Windows.Forms.PictureBox()
        Me.btnNikeFannyPack = New System.Windows.Forms.Button()
        Me.btnNikeSocks = New System.Windows.Forms.Button()
        Me.btnNikeBackPack = New System.Windows.Forms.Button()
        Me.lblNikeFannyPack = New System.Windows.Forms.Label()
        Me.lblNikeBackPack = New System.Windows.Forms.Label()
        Me.lblNikeSocks = New System.Windows.Forms.Label()
        Me.lblTotalDollars = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblCopyright = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.PanelDDMen.SuspendLayout()
        Me.PanelDDWomen.SuspendLayout()
        CType(Me.PicBoxNike1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxJordan2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxJordan1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidas1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidas2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNike2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxCart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeCloth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidasCloth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidasCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxJordanCloth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxJordanCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidasWomenCloth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxAdidasWomenCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenPumaCloth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenPumaCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenNikeCloth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenNikeCloth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenAdidasShoes1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenAdidasShoes2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenNikeShoes1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenNikeShoes2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxWomenJordanShoes1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxFannyPack2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxFannyPack1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeSocks1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeSocks2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeBackPack1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxNikeBackPack2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.PanelDDMen)
        Me.FlowLayoutPanel1.Controls.Add(Me.PanelDDWomen)
        Me.FlowLayoutPanel1.Controls.Add(Me.btnAccessories)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(751, 95)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'PanelDDMen
        '
        Me.PanelDDMen.Controls.Add(Me.BtnClothing)
        Me.PanelDDMen.Controls.Add(Me.BtnShoes)
        Me.PanelDDMen.Controls.Add(Me.BtnMen)
        Me.PanelDDMen.Location = New System.Drawing.Point(3, 3)
        Me.PanelDDMen.Name = "PanelDDMen"
        Me.PanelDDMen.Size = New System.Drawing.Size(251, 38)
        Me.PanelDDMen.TabIndex = 2
        '
        'BtnClothing
        '
        Me.BtnClothing.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnClothing.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnClothing.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnClothing.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClothing.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnClothing.Location = New System.Drawing.Point(0, 62)
        Me.BtnClothing.Name = "BtnClothing"
        Me.BtnClothing.Size = New System.Drawing.Size(251, 30)
        Me.BtnClothing.TabIndex = 5
        Me.BtnClothing.Text = "Clothing"
        Me.BtnClothing.UseVisualStyleBackColor = False
        '
        'BtnShoes
        '
        Me.BtnShoes.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnShoes.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnShoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnShoes.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnShoes.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnShoes.Location = New System.Drawing.Point(0, 38)
        Me.BtnShoes.Name = "BtnShoes"
        Me.BtnShoes.Size = New System.Drawing.Size(251, 24)
        Me.BtnShoes.TabIndex = 4
        Me.BtnShoes.Text = "Shoes"
        Me.BtnShoes.UseVisualStyleBackColor = False
        '
        'BtnMen
        '
        Me.BtnMen.BackColor = System.Drawing.Color.Navy
        Me.BtnMen.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnMen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMen.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMen.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnMen.Image = CType(resources.GetObject("BtnMen.Image"), System.Drawing.Image)
        Me.BtnMen.Location = New System.Drawing.Point(0, 0)
        Me.BtnMen.Name = "BtnMen"
        Me.BtnMen.Size = New System.Drawing.Size(251, 38)
        Me.BtnMen.TabIndex = 3
        Me.BtnMen.Text = "               Men                    "
        Me.BtnMen.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.BtnMen.UseVisualStyleBackColor = False
        '
        'PanelDDWomen
        '
        Me.PanelDDWomen.Controls.Add(Me.BtnWomenClothes)
        Me.PanelDDWomen.Controls.Add(Me.BtnWomenShoes)
        Me.PanelDDWomen.Controls.Add(Me.BtnWomen)
        Me.PanelDDWomen.Location = New System.Drawing.Point(260, 3)
        Me.PanelDDWomen.Name = "PanelDDWomen"
        Me.PanelDDWomen.Size = New System.Drawing.Size(251, 38)
        Me.PanelDDWomen.TabIndex = 4
        '
        'BtnWomenClothes
        '
        Me.BtnWomenClothes.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnWomenClothes.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnWomenClothes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWomenClothes.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWomenClothes.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnWomenClothes.Location = New System.Drawing.Point(0, 62)
        Me.BtnWomenClothes.Name = "BtnWomenClothes"
        Me.BtnWomenClothes.Size = New System.Drawing.Size(251, 24)
        Me.BtnWomenClothes.TabIndex = 7
        Me.BtnWomenClothes.Text = "Clothes"
        Me.BtnWomenClothes.UseVisualStyleBackColor = False
        '
        'BtnWomenShoes
        '
        Me.BtnWomenShoes.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnWomenShoes.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnWomenShoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWomenShoes.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWomenShoes.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnWomenShoes.Location = New System.Drawing.Point(0, 38)
        Me.BtnWomenShoes.Name = "BtnWomenShoes"
        Me.BtnWomenShoes.Size = New System.Drawing.Size(251, 24)
        Me.BtnWomenShoes.TabIndex = 6
        Me.BtnWomenShoes.Text = "Shoes"
        Me.BtnWomenShoes.UseVisualStyleBackColor = False
        '
        'BtnWomen
        '
        Me.BtnWomen.BackColor = System.Drawing.Color.Navy
        Me.BtnWomen.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnWomen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnWomen.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWomen.ForeColor = System.Drawing.Color.GhostWhite
        Me.BtnWomen.Image = CType(resources.GetObject("BtnWomen.Image"), System.Drawing.Image)
        Me.BtnWomen.Location = New System.Drawing.Point(0, 0)
        Me.BtnWomen.Name = "BtnWomen"
        Me.BtnWomen.Size = New System.Drawing.Size(251, 38)
        Me.BtnWomen.TabIndex = 3
        Me.BtnWomen.Text = "            Women                     "
        Me.BtnWomen.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnWomen.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.BtnWomen.UseVisualStyleBackColor = False
        '
        'btnAccessories
        '
        Me.btnAccessories.BackColor = System.Drawing.Color.Navy
        Me.btnAccessories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAccessories.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAccessories.ForeColor = System.Drawing.Color.GhostWhite
        Me.btnAccessories.Location = New System.Drawing.Point(517, 3)
        Me.btnAccessories.Name = "btnAccessories"
        Me.btnAccessories.Size = New System.Drawing.Size(230, 38)
        Me.btnAccessories.TabIndex = 4
        Me.btnAccessories.Text = "Accessories"
        Me.btnAccessories.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 25
        '
        'Timer2
        '
        Me.Timer2.Interval = 25
        '
        'PicBoxNike1
        '
        Me.PicBoxNike1.Image = CType(resources.GetObject("PicBoxNike1.Image"), System.Drawing.Image)
        Me.PicBoxNike1.Location = New System.Drawing.Point(70, 118)
        Me.PicBoxNike1.Name = "PicBoxNike1"
        Me.PicBoxNike1.Size = New System.Drawing.Size(174, 212)
        Me.PicBoxNike1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNike1.TabIndex = 1
        Me.PicBoxNike1.TabStop = False
        Me.PicBoxNike1.Visible = False
        '
        'PicBoxJordan2
        '
        Me.PicBoxJordan2.Image = CType(resources.GetObject("PicBoxJordan2.Image"), System.Drawing.Image)
        Me.PicBoxJordan2.Location = New System.Drawing.Point(529, 118)
        Me.PicBoxJordan2.Name = "PicBoxJordan2"
        Me.PicBoxJordan2.Size = New System.Drawing.Size(53, 212)
        Me.PicBoxJordan2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxJordan2.TabIndex = 4
        Me.PicBoxJordan2.TabStop = False
        Me.PicBoxJordan2.Visible = False
        '
        'PicBoxJordan1
        '
        Me.PicBoxJordan1.Image = CType(resources.GetObject("PicBoxJordan1.Image"), System.Drawing.Image)
        Me.PicBoxJordan1.Location = New System.Drawing.Point(581, 118)
        Me.PicBoxJordan1.Name = "PicBoxJordan1"
        Me.PicBoxJordan1.Size = New System.Drawing.Size(158, 212)
        Me.PicBoxJordan1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxJordan1.TabIndex = 5
        Me.PicBoxJordan1.TabStop = False
        Me.PicBoxJordan1.Visible = False
        '
        'PicBoxAdidas1
        '
        Me.PicBoxAdidas1.Image = CType(resources.GetObject("PicBoxAdidas1.Image"), System.Drawing.Image)
        Me.PicBoxAdidas1.Location = New System.Drawing.Point(337, 118)
        Me.PicBoxAdidas1.Name = "PicBoxAdidas1"
        Me.PicBoxAdidas1.Size = New System.Drawing.Size(166, 212)
        Me.PicBoxAdidas1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidas1.TabIndex = 6
        Me.PicBoxAdidas1.TabStop = False
        Me.PicBoxAdidas1.Visible = False
        '
        'PicBoxAdidas2
        '
        Me.PicBoxAdidas2.Image = CType(resources.GetObject("PicBoxAdidas2.Image"), System.Drawing.Image)
        Me.PicBoxAdidas2.Location = New System.Drawing.Point(272, 118)
        Me.PicBoxAdidas2.Name = "PicBoxAdidas2"
        Me.PicBoxAdidas2.Size = New System.Drawing.Size(64, 212)
        Me.PicBoxAdidas2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidas2.TabIndex = 7
        Me.PicBoxAdidas2.TabStop = False
        Me.PicBoxAdidas2.Visible = False
        '
        'PicBoxNike2
        '
        Me.PicBoxNike2.Image = CType(resources.GetObject("PicBoxNike2.Image"), System.Drawing.Image)
        Me.PicBoxNike2.Location = New System.Drawing.Point(24, 118)
        Me.PicBoxNike2.Name = "PicBoxNike2"
        Me.PicBoxNike2.Size = New System.Drawing.Size(55, 212)
        Me.PicBoxNike2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNike2.TabIndex = 8
        Me.PicBoxNike2.TabStop = False
        Me.PicBoxNike2.Visible = False
        '
        'btnMenNike1
        '
        Me.btnMenNike1.BackColor = System.Drawing.Color.DarkOrange
        Me.btnMenNike1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMenNike1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenNike1.ForeColor = System.Drawing.Color.Black
        Me.btnMenNike1.Location = New System.Drawing.Point(81, 373)
        Me.btnMenNike1.Name = "btnMenNike1"
        Me.btnMenNike1.Size = New System.Drawing.Size(102, 34)
        Me.btnMenNike1.TabIndex = 9
        Me.btnMenNike1.Text = "Add to Cart"
        Me.btnMenNike1.UseVisualStyleBackColor = False
        Me.btnMenNike1.Visible = False
        '
        'btnMenAdidas1
        '
        Me.btnMenAdidas1.BackColor = System.Drawing.Color.DarkOrange
        Me.btnMenAdidas1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMenAdidas1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenAdidas1.ForeColor = System.Drawing.Color.Black
        Me.btnMenAdidas1.Location = New System.Drawing.Point(337, 373)
        Me.btnMenAdidas1.Name = "btnMenAdidas1"
        Me.btnMenAdidas1.Size = New System.Drawing.Size(102, 34)
        Me.btnMenAdidas1.TabIndex = 10
        Me.btnMenAdidas1.Text = "Add to Cart"
        Me.btnMenAdidas1.UseVisualStyleBackColor = False
        Me.btnMenAdidas1.Visible = False
        '
        'btnMenJordan1
        '
        Me.btnMenJordan1.BackColor = System.Drawing.Color.DarkOrange
        Me.btnMenJordan1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMenJordan1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenJordan1.ForeColor = System.Drawing.Color.Black
        Me.btnMenJordan1.Location = New System.Drawing.Point(593, 373)
        Me.btnMenJordan1.Name = "btnMenJordan1"
        Me.btnMenJordan1.Size = New System.Drawing.Size(102, 34)
        Me.btnMenJordan1.TabIndex = 11
        Me.btnMenJordan1.Text = "Add to Cart"
        Me.btnMenJordan1.UseVisualStyleBackColor = False
        Me.btnMenJordan1.Visible = False
        '
        'lblMenNike
        '
        Me.lblMenNike.AutoSize = True
        Me.lblMenNike.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenNike.Location = New System.Drawing.Point(21, 355)
        Me.lblMenNike.Name = "lblMenNike"
        Me.lblMenNike.Size = New System.Drawing.Size(197, 15)
        Me.lblMenNike.TabIndex = 12
        Me.lblMenNike.Text = "Men's Nike Air Max Vapor  : $190.00"
        Me.lblMenNike.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenNike.Visible = False
        '
        'lblMenAdidas
        '
        Me.lblMenAdidas.AutoSize = True
        Me.lblMenAdidas.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenAdidas.Location = New System.Drawing.Point(269, 355)
        Me.lblMenAdidas.Name = "lblMenAdidas"
        Me.lblMenAdidas.Size = New System.Drawing.Size(209, 15)
        Me.lblMenAdidas.TabIndex = 13
        Me.lblMenAdidas.Text = "Men's Adidas Running Shoes : $130.00"
        Me.lblMenAdidas.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenAdidas.Visible = False
        '
        'lblMenJordan
        '
        Me.lblMenJordan.AutoSize = True
        Me.lblMenJordan.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenJordan.Location = New System.Drawing.Point(541, 355)
        Me.lblMenJordan.Name = "lblMenJordan"
        Me.lblMenJordan.Size = New System.Drawing.Size(191, 15)
        Me.lblMenJordan.TabIndex = 14
        Me.lblMenJordan.Text = "Men's Nike Air Jordan 1's  : $200.00"
        Me.lblMenJordan.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenJordan.Visible = False
        '
        'PicBoxCart
        '
        Me.PicBoxCart.Image = CType(resources.GetObject("PicBoxCart.Image"), System.Drawing.Image)
        Me.PicBoxCart.Location = New System.Drawing.Point(1, 505)
        Me.PicBoxCart.Name = "PicBoxCart"
        Me.PicBoxCart.Size = New System.Drawing.Size(78, 95)
        Me.PicBoxCart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxCart.TabIndex = 15
        Me.PicBoxCart.TabStop = False
        Me.PicBoxCart.Visible = False
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(81, 501)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(310, 100)
        Me.ListBox1.TabIndex = 16
        Me.ListBox1.Visible = False
        '
        'btnCheckout
        '
        Me.btnCheckout.BackColor = System.Drawing.Color.DarkOrange
        Me.btnCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheckout.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckout.ForeColor = System.Drawing.Color.Black
        Me.btnCheckout.Location = New System.Drawing.Point(572, 567)
        Me.btnCheckout.Name = "btnCheckout"
        Me.btnCheckout.Size = New System.Drawing.Size(110, 34)
        Me.btnCheckout.TabIndex = 17
        Me.btnCheckout.Text = "Check Out"
        Me.btnCheckout.UseVisualStyleBackColor = False
        Me.btnCheckout.Visible = False
        '
        'btnRemove
        '
        Me.btnRemove.BackColor = System.Drawing.Color.DarkOrange
        Me.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRemove.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemove.ForeColor = System.Drawing.Color.Black
        Me.btnRemove.Location = New System.Drawing.Point(389, 554)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(102, 34)
        Me.btnRemove.TabIndex = 18
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.UseVisualStyleBackColor = False
        Me.btnRemove.Visible = False
        '
        'lblTotalAmount
        '
        Me.lblTotalAmount.AutoSize = True
        Me.lblTotalAmount.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalAmount.Location = New System.Drawing.Point(511, 523)
        Me.lblTotalAmount.Name = "lblTotalAmount"
        Me.lblTotalAmount.Size = New System.Drawing.Size(71, 25)
        Me.lblTotalAmount.TabIndex = 19
        Me.lblTotalAmount.Text = "Total :"
        Me.lblTotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblTotalAmount.Visible = False
        '
        'PicBoxNikeCloth1
        '
        Me.PicBoxNikeCloth1.Image = CType(resources.GetObject("PicBoxNikeCloth1.Image"), System.Drawing.Image)
        Me.PicBoxNikeCloth1.Location = New System.Drawing.Point(70, 118)
        Me.PicBoxNikeCloth1.Name = "PicBoxNikeCloth1"
        Me.PicBoxNikeCloth1.Size = New System.Drawing.Size(174, 212)
        Me.PicBoxNikeCloth1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeCloth1.TabIndex = 20
        Me.PicBoxNikeCloth1.TabStop = False
        Me.PicBoxNikeCloth1.Visible = False
        '
        'PicBoxNikeCloth2
        '
        Me.PicBoxNikeCloth2.Image = CType(resources.GetObject("PicBoxNikeCloth2.Image"), System.Drawing.Image)
        Me.PicBoxNikeCloth2.Location = New System.Drawing.Point(24, 118)
        Me.PicBoxNikeCloth2.Name = "PicBoxNikeCloth2"
        Me.PicBoxNikeCloth2.Size = New System.Drawing.Size(55, 212)
        Me.PicBoxNikeCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeCloth2.TabIndex = 21
        Me.PicBoxNikeCloth2.TabStop = False
        Me.PicBoxNikeCloth2.Visible = False
        '
        'lblMenNikeCloth
        '
        Me.lblMenNikeCloth.AutoSize = True
        Me.lblMenNikeCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenNikeCloth.Location = New System.Drawing.Point(50, 355)
        Me.lblMenNikeCloth.Name = "lblMenNikeCloth"
        Me.lblMenNikeCloth.Size = New System.Drawing.Size(168, 15)
        Me.lblMenNikeCloth.TabIndex = 22
        Me.lblMenNikeCloth.Text = "Men's Nike Air Hoodie : $55.00"
        Me.lblMenNikeCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenNikeCloth.Visible = False
        '
        'PicBoxAdidasCloth1
        '
        Me.PicBoxAdidasCloth1.Image = CType(resources.GetObject("PicBoxAdidasCloth1.Image"), System.Drawing.Image)
        Me.PicBoxAdidasCloth1.Location = New System.Drawing.Point(337, 118)
        Me.PicBoxAdidasCloth1.Name = "PicBoxAdidasCloth1"
        Me.PicBoxAdidasCloth1.Size = New System.Drawing.Size(166, 212)
        Me.PicBoxAdidasCloth1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidasCloth1.TabIndex = 23
        Me.PicBoxAdidasCloth1.TabStop = False
        Me.PicBoxAdidasCloth1.Visible = False
        '
        'PicBoxAdidasCloth2
        '
        Me.PicBoxAdidasCloth2.Image = CType(resources.GetObject("PicBoxAdidasCloth2.Image"), System.Drawing.Image)
        Me.PicBoxAdidasCloth2.Location = New System.Drawing.Point(272, 118)
        Me.PicBoxAdidasCloth2.Name = "PicBoxAdidasCloth2"
        Me.PicBoxAdidasCloth2.Size = New System.Drawing.Size(64, 212)
        Me.PicBoxAdidasCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidasCloth2.TabIndex = 24
        Me.PicBoxAdidasCloth2.TabStop = False
        Me.PicBoxAdidasCloth2.Visible = False
        '
        'lblMenAdidasCloth
        '
        Me.lblMenAdidasCloth.AutoSize = True
        Me.lblMenAdidasCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenAdidasCloth.Location = New System.Drawing.Point(312, 355)
        Me.lblMenAdidasCloth.Name = "lblMenAdidasCloth"
        Me.lblMenAdidasCloth.Size = New System.Drawing.Size(177, 15)
        Me.lblMenAdidasCloth.TabIndex = 25
        Me.lblMenAdidasCloth.Text = "Men's Adidas Sweatshirt : $70.00"
        Me.lblMenAdidasCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenAdidasCloth.Visible = False
        '
        'PicBoxJordanCloth
        '
        Me.PicBoxJordanCloth.Image = CType(resources.GetObject("PicBoxJordanCloth.Image"), System.Drawing.Image)
        Me.PicBoxJordanCloth.Location = New System.Drawing.Point(581, 118)
        Me.PicBoxJordanCloth.Name = "PicBoxJordanCloth"
        Me.PicBoxJordanCloth.Size = New System.Drawing.Size(158, 212)
        Me.PicBoxJordanCloth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxJordanCloth.TabIndex = 26
        Me.PicBoxJordanCloth.TabStop = False
        Me.PicBoxJordanCloth.Visible = False
        '
        'PicBoxJordanCloth2
        '
        Me.PicBoxJordanCloth2.Image = CType(resources.GetObject("PicBoxJordanCloth2.Image"), System.Drawing.Image)
        Me.PicBoxJordanCloth2.Location = New System.Drawing.Point(529, 118)
        Me.PicBoxJordanCloth2.Name = "PicBoxJordanCloth2"
        Me.PicBoxJordanCloth2.Size = New System.Drawing.Size(53, 212)
        Me.PicBoxJordanCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxJordanCloth2.TabIndex = 27
        Me.PicBoxJordanCloth2.TabStop = False
        Me.PicBoxJordanCloth2.Visible = False
        '
        'lblMenJordanCloth
        '
        Me.lblMenJordanCloth.AutoSize = True
        Me.lblMenJordanCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenJordanCloth.Location = New System.Drawing.Point(536, 355)
        Me.lblMenJordanCloth.Name = "lblMenJordanCloth"
        Me.lblMenJordanCloth.Size = New System.Drawing.Size(211, 15)
        Me.lblMenJordanCloth.TabIndex = 28
        Me.lblMenJordanCloth.Text = "Men's Air Nike Jordan Hoodie  : $80.00"
        Me.lblMenJordanCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblMenJordanCloth.Visible = False
        '
        'btnJordanCloth
        '
        Me.btnJordanCloth.BackColor = System.Drawing.Color.DarkOrange
        Me.btnJordanCloth.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnJordanCloth.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnJordanCloth.ForeColor = System.Drawing.Color.Black
        Me.btnJordanCloth.Location = New System.Drawing.Point(593, 373)
        Me.btnJordanCloth.Name = "btnJordanCloth"
        Me.btnJordanCloth.Size = New System.Drawing.Size(102, 34)
        Me.btnJordanCloth.TabIndex = 31
        Me.btnJordanCloth.Text = "Add to Cart"
        Me.btnJordanCloth.UseVisualStyleBackColor = False
        Me.btnJordanCloth.Visible = False
        '
        'btnAdidasCloth
        '
        Me.btnAdidasCloth.BackColor = System.Drawing.Color.DarkOrange
        Me.btnAdidasCloth.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdidasCloth.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdidasCloth.ForeColor = System.Drawing.Color.Black
        Me.btnAdidasCloth.Location = New System.Drawing.Point(337, 373)
        Me.btnAdidasCloth.Name = "btnAdidasCloth"
        Me.btnAdidasCloth.Size = New System.Drawing.Size(102, 34)
        Me.btnAdidasCloth.TabIndex = 30
        Me.btnAdidasCloth.Text = "Add to Cart"
        Me.btnAdidasCloth.UseVisualStyleBackColor = False
        Me.btnAdidasCloth.Visible = False
        '
        'btnNikeCloth
        '
        Me.btnNikeCloth.BackColor = System.Drawing.Color.DarkOrange
        Me.btnNikeCloth.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNikeCloth.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNikeCloth.ForeColor = System.Drawing.Color.Black
        Me.btnNikeCloth.Location = New System.Drawing.Point(81, 373)
        Me.btnNikeCloth.Name = "btnNikeCloth"
        Me.btnNikeCloth.Size = New System.Drawing.Size(102, 34)
        Me.btnNikeCloth.TabIndex = 29
        Me.btnNikeCloth.Text = "Add to Cart"
        Me.btnNikeCloth.UseVisualStyleBackColor = False
        Me.btnNikeCloth.Visible = False
        '
        'PicBoxAdidasWomenCloth1
        '
        Me.PicBoxAdidasWomenCloth1.Image = CType(resources.GetObject("PicBoxAdidasWomenCloth1.Image"), System.Drawing.Image)
        Me.PicBoxAdidasWomenCloth1.Location = New System.Drawing.Point(337, 118)
        Me.PicBoxAdidasWomenCloth1.Name = "PicBoxAdidasWomenCloth1"
        Me.PicBoxAdidasWomenCloth1.Size = New System.Drawing.Size(166, 212)
        Me.PicBoxAdidasWomenCloth1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidasWomenCloth1.TabIndex = 32
        Me.PicBoxAdidasWomenCloth1.TabStop = False
        Me.PicBoxAdidasWomenCloth1.Visible = False
        '
        'PicBoxAdidasWomenCloth2
        '
        Me.PicBoxAdidasWomenCloth2.Image = CType(resources.GetObject("PicBoxAdidasWomenCloth2.Image"), System.Drawing.Image)
        Me.PicBoxAdidasWomenCloth2.Location = New System.Drawing.Point(272, 118)
        Me.PicBoxAdidasWomenCloth2.Name = "PicBoxAdidasWomenCloth2"
        Me.PicBoxAdidasWomenCloth2.Size = New System.Drawing.Size(64, 212)
        Me.PicBoxAdidasWomenCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxAdidasWomenCloth2.TabIndex = 33
        Me.PicBoxAdidasWomenCloth2.TabStop = False
        Me.PicBoxAdidasWomenCloth2.Visible = False
        '
        'PicBoxWomenPumaCloth1
        '
        Me.PicBoxWomenPumaCloth1.Image = CType(resources.GetObject("PicBoxWomenPumaCloth1.Image"), System.Drawing.Image)
        Me.PicBoxWomenPumaCloth1.Location = New System.Drawing.Point(581, 118)
        Me.PicBoxWomenPumaCloth1.Name = "PicBoxWomenPumaCloth1"
        Me.PicBoxWomenPumaCloth1.Size = New System.Drawing.Size(158, 212)
        Me.PicBoxWomenPumaCloth1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenPumaCloth1.TabIndex = 34
        Me.PicBoxWomenPumaCloth1.TabStop = False
        Me.PicBoxWomenPumaCloth1.Visible = False
        '
        'PicBoxWomenPumaCloth2
        '
        Me.PicBoxWomenPumaCloth2.Image = CType(resources.GetObject("PicBoxWomenPumaCloth2.Image"), System.Drawing.Image)
        Me.PicBoxWomenPumaCloth2.Location = New System.Drawing.Point(529, 118)
        Me.PicBoxWomenPumaCloth2.Name = "PicBoxWomenPumaCloth2"
        Me.PicBoxWomenPumaCloth2.Size = New System.Drawing.Size(53, 212)
        Me.PicBoxWomenPumaCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenPumaCloth2.TabIndex = 35
        Me.PicBoxWomenPumaCloth2.TabStop = False
        Me.PicBoxWomenPumaCloth2.Visible = False
        '
        'PicBoxWomenNikeCloth1
        '
        Me.PicBoxWomenNikeCloth1.Image = CType(resources.GetObject("PicBoxWomenNikeCloth1.Image"), System.Drawing.Image)
        Me.PicBoxWomenNikeCloth1.Location = New System.Drawing.Point(70, 118)
        Me.PicBoxWomenNikeCloth1.Name = "PicBoxWomenNikeCloth1"
        Me.PicBoxWomenNikeCloth1.Size = New System.Drawing.Size(174, 212)
        Me.PicBoxWomenNikeCloth1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenNikeCloth1.TabIndex = 36
        Me.PicBoxWomenNikeCloth1.TabStop = False
        Me.PicBoxWomenNikeCloth1.Visible = False
        '
        'PicBoxWomenNikeCloth2
        '
        Me.PicBoxWomenNikeCloth2.Image = CType(resources.GetObject("PicBoxWomenNikeCloth2.Image"), System.Drawing.Image)
        Me.PicBoxWomenNikeCloth2.Location = New System.Drawing.Point(24, 118)
        Me.PicBoxWomenNikeCloth2.Name = "PicBoxWomenNikeCloth2"
        Me.PicBoxWomenNikeCloth2.Size = New System.Drawing.Size(55, 212)
        Me.PicBoxWomenNikeCloth2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenNikeCloth2.TabIndex = 37
        Me.PicBoxWomenNikeCloth2.TabStop = False
        Me.PicBoxWomenNikeCloth2.Visible = False
        '
        'btnWomenPuma
        '
        Me.btnWomenPuma.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenPuma.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenPuma.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenPuma.ForeColor = System.Drawing.Color.Black
        Me.btnWomenPuma.Location = New System.Drawing.Point(593, 373)
        Me.btnWomenPuma.Name = "btnWomenPuma"
        Me.btnWomenPuma.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenPuma.TabIndex = 40
        Me.btnWomenPuma.Text = "Add to Cart"
        Me.btnWomenPuma.UseVisualStyleBackColor = False
        Me.btnWomenPuma.Visible = False
        '
        'btnWomenAdidas
        '
        Me.btnWomenAdidas.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenAdidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenAdidas.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenAdidas.ForeColor = System.Drawing.Color.Black
        Me.btnWomenAdidas.Location = New System.Drawing.Point(337, 373)
        Me.btnWomenAdidas.Name = "btnWomenAdidas"
        Me.btnWomenAdidas.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenAdidas.TabIndex = 39
        Me.btnWomenAdidas.Text = "Add to Cart"
        Me.btnWomenAdidas.UseVisualStyleBackColor = False
        Me.btnWomenAdidas.Visible = False
        '
        'btnWomenNike
        '
        Me.btnWomenNike.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenNike.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenNike.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenNike.ForeColor = System.Drawing.Color.Black
        Me.btnWomenNike.Location = New System.Drawing.Point(81, 373)
        Me.btnWomenNike.Name = "btnWomenNike"
        Me.btnWomenNike.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenNike.TabIndex = 38
        Me.btnWomenNike.Text = "Add to Cart"
        Me.btnWomenNike.UseVisualStyleBackColor = False
        Me.btnWomenNike.Visible = False
        '
        'lblWomenNikeCloth
        '
        Me.lblWomenNikeCloth.AutoSize = True
        Me.lblWomenNikeCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenNikeCloth.Location = New System.Drawing.Point(12, 355)
        Me.lblWomenNikeCloth.Name = "lblWomenNikeCloth"
        Me.lblWomenNikeCloth.Size = New System.Drawing.Size(243, 15)
        Me.lblWomenNikeCloth.TabIndex = 41
        Me.lblWomenNikeCloth.Text = "Women's Nike Sports Jacket Woven : $120.00"
        Me.lblWomenNikeCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenNikeCloth.Visible = False
        '
        'lblWomenAdidasCloth
        '
        Me.lblWomenAdidasCloth.AutoSize = True
        Me.lblWomenAdidasCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenAdidasCloth.Location = New System.Drawing.Point(272, 355)
        Me.lblWomenAdidasCloth.Name = "lblWomenAdidasCloth"
        Me.lblWomenAdidasCloth.Size = New System.Drawing.Size(231, 15)
        Me.lblWomenAdidasCloth.TabIndex = 42
        Me.lblWomenAdidasCloth.Text = "Women Adidas Originals Crop Top : $65.00"
        Me.lblWomenAdidasCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenAdidasCloth.Visible = False
        '
        'lblWomenPumaCloth
        '
        Me.lblWomenPumaCloth.AutoSize = True
        Me.lblWomenPumaCloth.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenPumaCloth.Location = New System.Drawing.Point(557, 355)
        Me.lblWomenPumaCloth.Name = "lblWomenPumaCloth"
        Me.lblWomenPumaCloth.Size = New System.Drawing.Size(190, 15)
        Me.lblWomenPumaCloth.TabIndex = 43
        Me.lblWomenPumaCloth.Text = "Womens' Puma Tape Dress : $25.00"
        Me.lblWomenPumaCloth.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenPumaCloth.Visible = False
        '
        'btnClearAll
        '
        Me.btnClearAll.BackColor = System.Drawing.Color.DarkOrange
        Me.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearAll.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearAll.ForeColor = System.Drawing.Color.Black
        Me.btnClearAll.Location = New System.Drawing.Point(389, 501)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(102, 34)
        Me.btnClearAll.TabIndex = 44
        Me.btnClearAll.Text = "Clear All"
        Me.btnClearAll.UseVisualStyleBackColor = False
        Me.btnClearAll.Visible = False
        '
        'PicBoxWomenAdidasShoes1
        '
        Me.PicBoxWomenAdidasShoes1.Image = CType(resources.GetObject("PicBoxWomenAdidasShoes1.Image"), System.Drawing.Image)
        Me.PicBoxWomenAdidasShoes1.Location = New System.Drawing.Point(337, 118)
        Me.PicBoxWomenAdidasShoes1.Name = "PicBoxWomenAdidasShoes1"
        Me.PicBoxWomenAdidasShoes1.Size = New System.Drawing.Size(166, 212)
        Me.PicBoxWomenAdidasShoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenAdidasShoes1.TabIndex = 45
        Me.PicBoxWomenAdidasShoes1.TabStop = False
        Me.PicBoxWomenAdidasShoes1.Visible = False
        '
        'PicBoxWomenAdidasShoes2
        '
        Me.PicBoxWomenAdidasShoes2.Image = CType(resources.GetObject("PicBoxWomenAdidasShoes2.Image"), System.Drawing.Image)
        Me.PicBoxWomenAdidasShoes2.Location = New System.Drawing.Point(275, 118)
        Me.PicBoxWomenAdidasShoes2.Name = "PicBoxWomenAdidasShoes2"
        Me.PicBoxWomenAdidasShoes2.Size = New System.Drawing.Size(64, 212)
        Me.PicBoxWomenAdidasShoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenAdidasShoes2.TabIndex = 46
        Me.PicBoxWomenAdidasShoes2.TabStop = False
        Me.PicBoxWomenAdidasShoes2.Visible = False
        '
        'PicBoxWomenNikeShoes1
        '
        Me.PicBoxWomenNikeShoes1.Image = CType(resources.GetObject("PicBoxWomenNikeShoes1.Image"), System.Drawing.Image)
        Me.PicBoxWomenNikeShoes1.Location = New System.Drawing.Point(81, 118)
        Me.PicBoxWomenNikeShoes1.Name = "PicBoxWomenNikeShoes1"
        Me.PicBoxWomenNikeShoes1.Size = New System.Drawing.Size(174, 212)
        Me.PicBoxWomenNikeShoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenNikeShoes1.TabIndex = 47
        Me.PicBoxWomenNikeShoes1.TabStop = False
        Me.PicBoxWomenNikeShoes1.Visible = False
        '
        'PicBoxWomenNikeShoes2
        '
        Me.PicBoxWomenNikeShoes2.Image = CType(resources.GetObject("PicBoxWomenNikeShoes2.Image"), System.Drawing.Image)
        Me.PicBoxWomenNikeShoes2.Location = New System.Drawing.Point(24, 118)
        Me.PicBoxWomenNikeShoes2.Name = "PicBoxWomenNikeShoes2"
        Me.PicBoxWomenNikeShoes2.Size = New System.Drawing.Size(55, 212)
        Me.PicBoxWomenNikeShoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenNikeShoes2.TabIndex = 48
        Me.PicBoxWomenNikeShoes2.TabStop = False
        Me.PicBoxWomenNikeShoes2.Visible = False
        '
        'PicBoxWomenJordanShoes1
        '
        Me.PicBoxWomenJordanShoes1.Image = CType(resources.GetObject("PicBoxWomenJordanShoes1.Image"), System.Drawing.Image)
        Me.PicBoxWomenJordanShoes1.Location = New System.Drawing.Point(581, 118)
        Me.PicBoxWomenJordanShoes1.Name = "PicBoxWomenJordanShoes1"
        Me.PicBoxWomenJordanShoes1.Size = New System.Drawing.Size(158, 212)
        Me.PicBoxWomenJordanShoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxWomenJordanShoes1.TabIndex = 49
        Me.PicBoxWomenJordanShoes1.TabStop = False
        Me.PicBoxWomenJordanShoes1.Visible = False
        '
        'PicBoxFannyPack2
        '
        Me.PicBoxFannyPack2.Image = CType(resources.GetObject("PicBoxFannyPack2.Image"), System.Drawing.Image)
        Me.PicBoxFannyPack2.Location = New System.Drawing.Point(529, 118)
        Me.PicBoxFannyPack2.Name = "PicBoxFannyPack2"
        Me.PicBoxFannyPack2.Size = New System.Drawing.Size(53, 212)
        Me.PicBoxFannyPack2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxFannyPack2.TabIndex = 50
        Me.PicBoxFannyPack2.TabStop = False
        Me.PicBoxFannyPack2.Visible = False
        '
        'btnWomenJordanShoes
        '
        Me.btnWomenJordanShoes.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenJordanShoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenJordanShoes.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenJordanShoes.ForeColor = System.Drawing.Color.Black
        Me.btnWomenJordanShoes.Location = New System.Drawing.Point(593, 373)
        Me.btnWomenJordanShoes.Name = "btnWomenJordanShoes"
        Me.btnWomenJordanShoes.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenJordanShoes.TabIndex = 53
        Me.btnWomenJordanShoes.Text = "Add to Cart"
        Me.btnWomenJordanShoes.UseVisualStyleBackColor = False
        Me.btnWomenJordanShoes.Visible = False
        '
        'btnWomenShoesAdidas
        '
        Me.btnWomenShoesAdidas.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenShoesAdidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenShoesAdidas.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenShoesAdidas.ForeColor = System.Drawing.Color.Black
        Me.btnWomenShoesAdidas.Location = New System.Drawing.Point(337, 373)
        Me.btnWomenShoesAdidas.Name = "btnWomenShoesAdidas"
        Me.btnWomenShoesAdidas.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenShoesAdidas.TabIndex = 52
        Me.btnWomenShoesAdidas.Text = "Add to Cart"
        Me.btnWomenShoesAdidas.UseVisualStyleBackColor = False
        Me.btnWomenShoesAdidas.Visible = False
        '
        'btnWomenShoesNike
        '
        Me.btnWomenShoesNike.BackColor = System.Drawing.Color.DarkOrange
        Me.btnWomenShoesNike.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnWomenShoesNike.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWomenShoesNike.ForeColor = System.Drawing.Color.Black
        Me.btnWomenShoesNike.Location = New System.Drawing.Point(81, 373)
        Me.btnWomenShoesNike.Name = "btnWomenShoesNike"
        Me.btnWomenShoesNike.Size = New System.Drawing.Size(102, 34)
        Me.btnWomenShoesNike.TabIndex = 51
        Me.btnWomenShoesNike.Text = "Add to Cart"
        Me.btnWomenShoesNike.UseVisualStyleBackColor = False
        Me.btnWomenShoesNike.Visible = False
        '
        'lblWomenAdidasShoes
        '
        Me.lblWomenAdidasShoes.AutoSize = True
        Me.lblWomenAdidasShoes.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenAdidasShoes.Location = New System.Drawing.Point(272, 355)
        Me.lblWomenAdidasShoes.Name = "lblWomenAdidasShoes"
        Me.lblWomenAdidasShoes.Size = New System.Drawing.Size(247, 15)
        Me.lblWomenAdidasShoes.TabIndex = 54
        Me.lblWomenAdidasShoes.Text = "Women's Adidas NMD Casual Shoes : $130.00"
        Me.lblWomenAdidasShoes.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenAdidasShoes.Visible = False
        '
        'lblWomenNikeShoes
        '
        Me.lblWomenNikeShoes.AutoSize = True
        Me.lblWomenNikeShoes.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenNikeShoes.Location = New System.Drawing.Point(21, 355)
        Me.lblWomenNikeShoes.Name = "lblWomenNikeShoes"
        Me.lblWomenNikeShoes.Size = New System.Drawing.Size(231, 15)
        Me.lblWomenNikeShoes.TabIndex = 55
        Me.lblWomenNikeShoes.Text = "Women's Nike Air Vapormax Plus : $190.00"
        Me.lblWomenNikeShoes.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenNikeShoes.Visible = False
        '
        'lblWomenJordanShoes
        '
        Me.lblWomenJordanShoes.AutoSize = True
        Me.lblWomenJordanShoes.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWomenJordanShoes.Location = New System.Drawing.Point(536, 355)
        Me.lblWomenJordanShoes.Name = "lblWomenJordanShoes"
        Me.lblWomenJordanShoes.Size = New System.Drawing.Size(207, 15)
        Me.lblWomenJordanShoes.TabIndex = 56
        Me.lblWomenJordanShoes.Text = "Women's Air Jordan Retro 7's : $100.00"
        Me.lblWomenJordanShoes.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblWomenJordanShoes.Visible = False
        '
        'PicBoxFannyPack1
        '
        Me.PicBoxFannyPack1.Image = CType(resources.GetObject("PicBoxFannyPack1.Image"), System.Drawing.Image)
        Me.PicBoxFannyPack1.Location = New System.Drawing.Point(581, 118)
        Me.PicBoxFannyPack1.Name = "PicBoxFannyPack1"
        Me.PicBoxFannyPack1.Size = New System.Drawing.Size(158, 212)
        Me.PicBoxFannyPack1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxFannyPack1.TabIndex = 57
        Me.PicBoxFannyPack1.TabStop = False
        Me.PicBoxFannyPack1.Visible = False
        '
        'PicBoxNikeSocks1
        '
        Me.PicBoxNikeSocks1.Image = CType(resources.GetObject("PicBoxNikeSocks1.Image"), System.Drawing.Image)
        Me.PicBoxNikeSocks1.Location = New System.Drawing.Point(337, 118)
        Me.PicBoxNikeSocks1.Name = "PicBoxNikeSocks1"
        Me.PicBoxNikeSocks1.Size = New System.Drawing.Size(166, 212)
        Me.PicBoxNikeSocks1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeSocks1.TabIndex = 58
        Me.PicBoxNikeSocks1.TabStop = False
        Me.PicBoxNikeSocks1.Visible = False
        '
        'PicBoxNikeSocks2
        '
        Me.PicBoxNikeSocks2.Image = CType(resources.GetObject("PicBoxNikeSocks2.Image"), System.Drawing.Image)
        Me.PicBoxNikeSocks2.Location = New System.Drawing.Point(275, 118)
        Me.PicBoxNikeSocks2.Name = "PicBoxNikeSocks2"
        Me.PicBoxNikeSocks2.Size = New System.Drawing.Size(64, 212)
        Me.PicBoxNikeSocks2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeSocks2.TabIndex = 59
        Me.PicBoxNikeSocks2.TabStop = False
        Me.PicBoxNikeSocks2.Visible = False
        '
        'PicBoxNikeBackPack1
        '
        Me.PicBoxNikeBackPack1.Image = CType(resources.GetObject("PicBoxNikeBackPack1.Image"), System.Drawing.Image)
        Me.PicBoxNikeBackPack1.Location = New System.Drawing.Point(80, 118)
        Me.PicBoxNikeBackPack1.Name = "PicBoxNikeBackPack1"
        Me.PicBoxNikeBackPack1.Size = New System.Drawing.Size(174, 212)
        Me.PicBoxNikeBackPack1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeBackPack1.TabIndex = 60
        Me.PicBoxNikeBackPack1.TabStop = False
        Me.PicBoxNikeBackPack1.Visible = False
        '
        'PicBoxNikeBackPack2
        '
        Me.PicBoxNikeBackPack2.Image = CType(resources.GetObject("PicBoxNikeBackPack2.Image"), System.Drawing.Image)
        Me.PicBoxNikeBackPack2.Location = New System.Drawing.Point(24, 118)
        Me.PicBoxNikeBackPack2.Name = "PicBoxNikeBackPack2"
        Me.PicBoxNikeBackPack2.Size = New System.Drawing.Size(55, 212)
        Me.PicBoxNikeBackPack2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBoxNikeBackPack2.TabIndex = 61
        Me.PicBoxNikeBackPack2.TabStop = False
        Me.PicBoxNikeBackPack2.Visible = False
        '
        'btnNikeFannyPack
        '
        Me.btnNikeFannyPack.BackColor = System.Drawing.Color.DarkOrange
        Me.btnNikeFannyPack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNikeFannyPack.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNikeFannyPack.ForeColor = System.Drawing.Color.Black
        Me.btnNikeFannyPack.Location = New System.Drawing.Point(593, 373)
        Me.btnNikeFannyPack.Name = "btnNikeFannyPack"
        Me.btnNikeFannyPack.Size = New System.Drawing.Size(102, 34)
        Me.btnNikeFannyPack.TabIndex = 64
        Me.btnNikeFannyPack.Text = "Add to Cart"
        Me.btnNikeFannyPack.UseVisualStyleBackColor = False
        Me.btnNikeFannyPack.Visible = False
        '
        'btnNikeSocks
        '
        Me.btnNikeSocks.BackColor = System.Drawing.Color.DarkOrange
        Me.btnNikeSocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNikeSocks.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNikeSocks.ForeColor = System.Drawing.Color.Black
        Me.btnNikeSocks.Location = New System.Drawing.Point(337, 373)
        Me.btnNikeSocks.Name = "btnNikeSocks"
        Me.btnNikeSocks.Size = New System.Drawing.Size(102, 34)
        Me.btnNikeSocks.TabIndex = 63
        Me.btnNikeSocks.Text = "Add to Cart"
        Me.btnNikeSocks.UseVisualStyleBackColor = False
        Me.btnNikeSocks.Visible = False
        '
        'btnNikeBackPack
        '
        Me.btnNikeBackPack.BackColor = System.Drawing.Color.DarkOrange
        Me.btnNikeBackPack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNikeBackPack.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNikeBackPack.ForeColor = System.Drawing.Color.Black
        Me.btnNikeBackPack.Location = New System.Drawing.Point(81, 373)
        Me.btnNikeBackPack.Name = "btnNikeBackPack"
        Me.btnNikeBackPack.Size = New System.Drawing.Size(102, 34)
        Me.btnNikeBackPack.TabIndex = 62
        Me.btnNikeBackPack.Text = "Add to Cart"
        Me.btnNikeBackPack.UseVisualStyleBackColor = False
        Me.btnNikeBackPack.Visible = False
        '
        'lblNikeFannyPack
        '
        Me.lblNikeFannyPack.AutoSize = True
        Me.lblNikeFannyPack.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNikeFannyPack.Location = New System.Drawing.Point(511, 355)
        Me.lblNikeFannyPack.Name = "lblNikeFannyPack"
        Me.lblNikeFannyPack.Size = New System.Drawing.Size(236, 15)
        Me.lblNikeFannyPack.TabIndex = 67
        Me.lblNikeFannyPack.Text = "Nike Sportswear Heritage Hip Pack : $50.00"
        Me.lblNikeFannyPack.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblNikeFannyPack.Visible = False
        '
        'lblNikeBackPack
        '
        Me.lblNikeBackPack.AutoSize = True
        Me.lblNikeBackPack.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNikeBackPack.Location = New System.Drawing.Point(46, 355)
        Me.lblNikeBackPack.Name = "lblNikeBackPack"
        Me.lblNikeBackPack.Size = New System.Drawing.Size(198, 15)
        Me.lblNikeBackPack.TabIndex = 66
        Me.lblNikeBackPack.Text = "Nike Heritage 2.0 Backpack : $35.00"
        Me.lblNikeBackPack.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblNikeBackPack.Visible = False
        '
        'lblNikeSocks
        '
        Me.lblNikeSocks.AutoSize = True
        Me.lblNikeSocks.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNikeSocks.Location = New System.Drawing.Point(300, 355)
        Me.lblNikeSocks.Name = "lblNikeSocks"
        Me.lblNikeSocks.Size = New System.Drawing.Size(178, 15)
        Me.lblNikeSocks.TabIndex = 65
        Me.lblNikeSocks.Text = "Nike 6-pack crew socks : $22.00"
        Me.lblNikeSocks.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblNikeSocks.Visible = False
        '
        'lblTotalDollars
        '
        Me.lblTotalDollars.AutoSize = True
        Me.lblTotalDollars.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalDollars.Location = New System.Drawing.Point(582, 523)
        Me.lblTotalDollars.Name = "lblTotalDollars"
        Me.lblTotalDollars.Size = New System.Drawing.Size(0, 25)
        Me.lblTotalDollars.TabIndex = 68
        Me.lblTotalDollars.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(30, 95)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(702, 377)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'lblCopyright
        '
        Me.lblCopyright.AutoSize = True
        Me.lblCopyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCopyright.Location = New System.Drawing.Point(186, 588)
        Me.lblCopyright.Name = "lblCopyright"
        Me.lblCopyright.Size = New System.Drawing.Size(378, 40)
        Me.lblCopyright.TabIndex = 69
        Me.lblCopyright.Text = "Copyright © 2019 WiseWorks, Inc All rights reserved " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'frmWiseWorks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(751, 612)
        Me.Controls.Add(Me.lblCopyright)
        Me.Controls.Add(Me.lblTotalDollars)
        Me.Controls.Add(Me.lblNikeFannyPack)
        Me.Controls.Add(Me.lblNikeBackPack)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblNikeSocks)
        Me.Controls.Add(Me.btnNikeFannyPack)
        Me.Controls.Add(Me.btnNikeSocks)
        Me.Controls.Add(Me.btnNikeBackPack)
        Me.Controls.Add(Me.PicBoxNikeBackPack2)
        Me.Controls.Add(Me.PicBoxNikeBackPack1)
        Me.Controls.Add(Me.PicBoxNikeSocks2)
        Me.Controls.Add(Me.PicBoxNikeSocks1)
        Me.Controls.Add(Me.PicBoxFannyPack1)
        Me.Controls.Add(Me.lblWomenJordanShoes)
        Me.Controls.Add(Me.lblWomenNikeShoes)
        Me.Controls.Add(Me.lblWomenAdidasShoes)
        Me.Controls.Add(Me.btnWomenJordanShoes)
        Me.Controls.Add(Me.btnWomenShoesAdidas)
        Me.Controls.Add(Me.btnWomenShoesNike)
        Me.Controls.Add(Me.PicBoxFannyPack2)
        Me.Controls.Add(Me.PicBoxWomenJordanShoes1)
        Me.Controls.Add(Me.PicBoxWomenNikeShoes2)
        Me.Controls.Add(Me.PicBoxWomenNikeShoes1)
        Me.Controls.Add(Me.PicBoxWomenAdidasShoes2)
        Me.Controls.Add(Me.PicBoxWomenAdidasShoes1)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.lblWomenPumaCloth)
        Me.Controls.Add(Me.lblWomenAdidasCloth)
        Me.Controls.Add(Me.lblWomenNikeCloth)
        Me.Controls.Add(Me.btnWomenPuma)
        Me.Controls.Add(Me.btnWomenAdidas)
        Me.Controls.Add(Me.btnWomenNike)
        Me.Controls.Add(Me.PicBoxWomenNikeCloth2)
        Me.Controls.Add(Me.PicBoxWomenNikeCloth1)
        Me.Controls.Add(Me.PicBoxWomenPumaCloth2)
        Me.Controls.Add(Me.PicBoxWomenPumaCloth1)
        Me.Controls.Add(Me.PicBoxAdidasWomenCloth2)
        Me.Controls.Add(Me.PicBoxAdidasWomenCloth1)
        Me.Controls.Add(Me.btnJordanCloth)
        Me.Controls.Add(Me.btnAdidasCloth)
        Me.Controls.Add(Me.btnNikeCloth)
        Me.Controls.Add(Me.lblMenJordanCloth)
        Me.Controls.Add(Me.PicBoxJordanCloth2)
        Me.Controls.Add(Me.PicBoxJordanCloth)
        Me.Controls.Add(Me.lblMenAdidasCloth)
        Me.Controls.Add(Me.PicBoxAdidasCloth2)
        Me.Controls.Add(Me.PicBoxAdidasCloth1)
        Me.Controls.Add(Me.lblMenNikeCloth)
        Me.Controls.Add(Me.PicBoxNikeCloth2)
        Me.Controls.Add(Me.PicBoxNikeCloth1)
        Me.Controls.Add(Me.lblTotalAmount)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnCheckout)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.PicBoxCart)
        Me.Controls.Add(Me.lblMenJordan)
        Me.Controls.Add(Me.lblMenAdidas)
        Me.Controls.Add(Me.lblMenNike)
        Me.Controls.Add(Me.btnMenJordan1)
        Me.Controls.Add(Me.btnMenAdidas1)
        Me.Controls.Add(Me.btnMenNike1)
        Me.Controls.Add(Me.PicBoxNike2)
        Me.Controls.Add(Me.PicBoxAdidas2)
        Me.Controls.Add(Me.PicBoxAdidas1)
        Me.Controls.Add(Me.PicBoxJordan1)
        Me.Controls.Add(Me.PicBoxJordan2)
        Me.Controls.Add(Me.PicBoxNike1)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Name = "frmWiseWorks"
        Me.Text = "Wise Works E-commerce"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.PanelDDMen.ResumeLayout(False)
        Me.PanelDDWomen.ResumeLayout(False)
        CType(Me.PicBoxNike1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxJordan2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxJordan1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidas1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidas2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNike2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxCart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeCloth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidasCloth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidasCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxJordanCloth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxJordanCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidasWomenCloth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxAdidasWomenCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenPumaCloth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenPumaCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenNikeCloth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenNikeCloth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenAdidasShoes1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenAdidasShoes2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenNikeShoes1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenNikeShoes2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxWomenJordanShoes1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxFannyPack2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxFannyPack1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeSocks1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeSocks2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeBackPack1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxNikeBackPack2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents PanelDDMen As Panel
    Friend WithEvents BtnMen As Button
    Friend WithEvents BtnClothing As Button
    Friend WithEvents BtnShoes As Button
    Friend WithEvents PanelDDWomen As Panel
    Friend WithEvents BtnWomenClothes As Button
    Friend WithEvents BtnWomen As Button
    Friend WithEvents btnAccessories As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents PicBoxNike1 As PictureBox
    Friend WithEvents PicBoxJordan2 As PictureBox
    Friend WithEvents PicBoxJordan1 As PictureBox
    Friend WithEvents PicBoxAdidas1 As PictureBox
    Friend WithEvents PicBoxAdidas2 As PictureBox
    Friend WithEvents PicBoxNike2 As PictureBox
    Friend WithEvents btnMenNike1 As Button
    Friend WithEvents btnMenAdidas1 As Button
    Friend WithEvents btnMenJordan1 As Button
    Friend WithEvents lblMenNike As Label
    Friend WithEvents lblMenAdidas As Label
    Friend WithEvents lblMenJordan As Label
    Friend WithEvents PicBoxCart As PictureBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents btnCheckout As Button
    Friend WithEvents btnRemove As Button
    Friend WithEvents lblTotalAmount As Label
    Friend WithEvents PicBoxNikeCloth1 As PictureBox
    Friend WithEvents PicBoxNikeCloth2 As PictureBox
    Friend WithEvents lblMenNikeCloth As Label
    Friend WithEvents PicBoxAdidasCloth1 As PictureBox
    Friend WithEvents PicBoxAdidasCloth2 As PictureBox
    Friend WithEvents lblMenAdidasCloth As Label
    Friend WithEvents PicBoxJordanCloth As PictureBox
    Friend WithEvents PicBoxJordanCloth2 As PictureBox
    Friend WithEvents lblMenJordanCloth As Label
    Friend WithEvents btnJordanCloth As Button
    Friend WithEvents btnAdidasCloth As Button
    Friend WithEvents btnNikeCloth As Button
    Protected WithEvents BtnWomenShoes As Button
    Friend WithEvents PicBoxAdidasWomenCloth1 As PictureBox
    Friend WithEvents PicBoxAdidasWomenCloth2 As PictureBox
    Friend WithEvents PicBoxWomenPumaCloth1 As PictureBox
    Friend WithEvents PicBoxWomenPumaCloth2 As PictureBox
    Friend WithEvents PicBoxWomenNikeCloth1 As PictureBox
    Friend WithEvents PicBoxWomenNikeCloth2 As PictureBox
    Friend WithEvents btnWomenPuma As Button
    Friend WithEvents btnWomenAdidas As Button
    Friend WithEvents btnWomenNike As Button
    Friend WithEvents lblWomenNikeCloth As Label
    Friend WithEvents lblWomenAdidasCloth As Label
    Friend WithEvents lblWomenPumaCloth As Label
    Friend WithEvents btnClearAll As Button
    Friend WithEvents PicBoxWomenAdidasShoes1 As PictureBox
    Friend WithEvents PicBoxWomenAdidasShoes2 As PictureBox
    Friend WithEvents PicBoxWomenNikeShoes1 As PictureBox
    Friend WithEvents PicBoxWomenNikeShoes2 As PictureBox
    Friend WithEvents PicBoxWomenJordanShoes1 As PictureBox
    Friend WithEvents PicBoxFannyPack2 As PictureBox
    Friend WithEvents btnWomenJordanShoes As Button
    Friend WithEvents btnWomenShoesAdidas As Button
    Friend WithEvents btnWomenShoesNike As Button
    Friend WithEvents lblWomenAdidasShoes As Label
    Friend WithEvents lblWomenNikeShoes As Label
    Friend WithEvents lblWomenJordanShoes As Label
    Friend WithEvents PicBoxFannyPack1 As PictureBox
    Friend WithEvents PicBoxNikeSocks1 As PictureBox
    Friend WithEvents PicBoxNikeSocks2 As PictureBox
    Friend WithEvents PicBoxNikeBackPack1 As PictureBox
    Friend WithEvents PicBoxNikeBackPack2 As PictureBox
    Friend WithEvents btnNikeFannyPack As Button
    Friend WithEvents btnNikeSocks As Button
    Friend WithEvents btnNikeBackPack As Button
    Friend WithEvents lblNikeFannyPack As Label
    Friend WithEvents lblNikeBackPack As Label
    Friend WithEvents lblNikeSocks As Label
    Friend WithEvents lblTotalDollars As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblCopyright As Label
End Class
